# CalculatorApp – Basic Console Calculator

This is a simple console-based calculator application developed in C# as part of the Patika+ graduation project. The application allows users to perform basic arithmetic operations via a text-based interface.

--> Features

- Addition
- Subtraction
- Multiplication
- Division
- Error handling for invalid inputs


--> Technologies Used

- C#
- .NET Framework
- Visual Studio 2022


-Bekir Batuhan Duru

